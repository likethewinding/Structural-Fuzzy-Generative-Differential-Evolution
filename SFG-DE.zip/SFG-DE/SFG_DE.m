function [gbestX,gbestfitness,gbesthistory]=SFG_DE(N,D,ub,lb,MaxFEs,Func,FuncId)

%% Lnitialization
FEs=0;
gbestfitness=inf;
gbesthistory=inf(1,MaxFEs);
X=lb+(ub-lb).*rand(N,D);
V=lb+(ub-lb).*rand(N,D);
U=lb+(ub-lb).*rand(N,D);
X_SupBetter=lb+(ub-lb).*rand(N,D);
X_SupWorse=lb+(ub-lb).*rand(N,D);
X_Self=lb+(ub-lb).*rand(N,D);
w_M1=rand(N,D);
w_M2=rand(N,D);
w_M3=rand(N,D);
EDA_X_SupBetter=lb+(ub-lb).*rand(N,D);
EDA_X_SupWorse=lb+(ub-lb).*rand(N,D);
EDA_X=lb+(ub-lb).*rand(N,D);
mu1=rand(1,D);
sigma1=rand(1,D);
mu2=rand(1,D);
sigma2=rand(1,D);
mu3=rand(1,D);
sigma3=rand(1,D);
w_SupBetter=rand(N,D);
w_SupWorse=rand(N,D);
w_Self=rand(N,D);
f=inf(1,N);
T=0.1;
Tr=2;
weight=log(N+1/2)-log(1:N);
weight=weight./sum(weight);
Ff=rand(1,N);
Q=zeros(2,2,N);
state=ceil(2*rand(1,N));
new_state=state;
Pr=0.5*ones(2,2,N);
life=zeros(1,N);
life_end=10^(-((2*D - 10) / 20 + 0))*MaxFEs*ones(1,N);
for i =1:N
    X(i,:)=lb+(ub-lb).*rand(1,D);
    f(i)= Func(X(i,:)',FuncId);
    FEs=FEs+1;
    if gbestfitness>f(i)
        gbestfitness=f(i);
        gbestX= X(i,:);
    end
    gbesthistory(FEs)=gbestfitness;
end
ufitness=f;
%% Main loop
while 1

    %% Structural fuzzy generative mutation strategy
    maxf=max(f);
    minf=min(f);
    oldSF=Ff;
    Ff=1-(maxf-f+minf)/sum(maxf-f+minf);
    c=FEs/MaxFEs;
    Ff=c*oldSF+(1-c)*Ff;
    eta1=zeros(1,N);eta2=zeros(1,N);
    for i=1:N
        indices = find(f > f(i));
        if isempty(indices)
            volume=1;
        else
            volume=length(indices);
        end
        volume=ceil(volume*rand);
        Gap=zeros(volume,D);
        Distance=zeros(1,volume);
        for k=1:volume
            if rand<Pr(state(i),1,i)
                r=randperm(N,2);
                r1=r(1);
                r2=r(2);
                if f(r2)<f(r1)
                    t=r1; r1=r2; r2=t;
                end
                Gap(k,:)=(X(r1,:)-X(r2,:));
                eta1(i)=eta1(i)+1;
            else
                r=randperm(N,2);
                r1=r(1);
                r2=r(2);
                Gap(k,:)=(X(r1,:)-X(r2,:));
                eta2(i)=eta2(i)+1;
            end
            Distance(k)=norm(Gap(k,:),'fro');
        end
        SDistance=sum(Distance);
        minDistance=min(Distance);
        Fd=(SDistance-Distance+minDistance)./sum((SDistance-Distance+minDistance));
        newLF=mean(Fd);
        Fd=c*Fd+(1-c)*newLF;
        V(i,:)=X(i,:)+Ff(i)*(Fd*Gap);
    end
    U=V;

    % Boundary constraints
    flagub=U>ub;
    flaglb=U<lb;
    flag=(flagub+flaglb);
    U=(U.*(~flag))+(lb+(ub-lb)*rand(N,D)).*flag;

    %% Metropolis criterion and individual regeneration selection strategy
    ufitness=Func(U',FuncId);
    for i=1:N
        if ufitness(i)<f(i)
            new_state(i)=1;
            life(i)=0;
            X(i,:)=U(i,:);
            f(i)=ufitness(i);
            FEs=FEs+1;
            if gbestfitness>f(i)
                gbestfitness=f(i);
                gbestX=X(i,:);
            end
            gbesthistory(FEs)=gbestfitness;
        else
            new_state(i)=2;
            FEs=FEs+1;
            gbesthistory(FEs)=gbestfitness;
            if rand<=exp(-((ufitness(i)-f(i))/f(i))/T)
                X(i,:)=U(i,:);
                f(i)=ufitness(i);
            else
                life(i)=life(i)+1;
                if life(i)>=life_end(i)
                    life_end(i)=life_end(i)+N;
                    if rand<rand
                        X(i,:)=lb+(ub-lb)*rand(1,D);
                    else
                        Rp=randperm(D,ceil(D*rand));
                        X(i,Rp)=lb+(ub-lb)*rand(1,length(Rp));
                    end
                    f(i)=Func(X(i,:)',FuncId);
                    FEs=FEs+1;
                    if gbestfitness>f(i)
                        gbestfitness=f(i);
                        gbestX=X(i,:);
                    end
                    gbesthistory(FEs)=gbestfitness;
                end
            end
        end
        if FEs>=MaxFEs
            break;
        end
    end
    for i=1:N
        for a=1:2
            for s=1:2
                Pr(s,a,i)=exp(1)^(Q(s,a,i)/Tr)/(exp(1)^(Q(s,1,i)/Tr)+exp(1)^(Q(s,2,i)/Tr));
            end
        end
    end
    for i=1:N
        Q(state(i),1,i)=Q(new_state(i),1,i)+0.9*(eta1(i)+0.1*max(Q(new_state(i),:,i))-Q(state(i),1,i));
        Q(state(i),2,i)=Q(new_state(i),2,i)+0.9*(eta2(i)+0.1*max(Q(new_state(i),:,i))-Q(state(i),2,i));
        state(i)=new_state(i);
    end

    %% Estimation of univariate Gaussian distribution mutation strategy
    [~, sorted_indices] = sort(f);
    rankings = zeros(size(f));
    for rank = 1:length(sorted_indices)
        rankings(sorted_indices(rank)) = rank;
    end
    for i=1:N
        indices1 = find(f <= f(i));
        indices2 = find(f >= f(i));
        indices3 = randi(N,1,D);
        indexlen1=length(indices1);
        indexlen2=length(indices2);
        indexlen3=length(indices3);
        select1=indices1(randi(indexlen1,1,D));
        select2=indices2(randi(indexlen2,1,D));
        select3=indices3(randi(indexlen3,1,D));
        for j=1:D
            X_SupBetter(i,j)=X(select1(j),j);
            w_M1(i,j)=weight(rankings(select1(j)));
            X_SupWorse(i,j)=X(select2(j),j);
            w_M2(i,j)=weight(rankings(select2(j)));
            X_Self(i,j)=X(select3(j),j);
            w_M3(i,j)=weight(rankings(select3(j)));
        end
    end
    for j=1:D
        w_SupBetter(:,j)=w_M1(:,j)./sum(w_M1(:,j));
        mu1(j)=sum(w_SupBetter(:,j).*X_SupBetter(:,j));
        sigma1(j)=sqrt(sum(w_SupBetter(:,j).*(X_SupBetter(:,j)-mu1(j)).^2));
        w_SupWorse(:,j)=w_M2(:,j)./sum(w_M2(:,j));
        mu2(j)=sum(w_SupWorse(:,j).*X_SupWorse(:,j));
        sigma2(j)=sqrt(sum(w_SupWorse(:,j).*(X_SupWorse(:,j)-mu2(j)).^2));
        w_Self(:,j)=w_M3(:,j)./sum(w_M3(:,j));
        mu3(j)=sum(w_Self(:,j).*X_Self(:,j));
        sigma3(j)=sqrt(sum(w_Self(:,j).*(X_Self(:,j)-mu3(j)).^2));
    end
    EDA_X_SupBetter=mu1+sigma1.*randn(N,D);
    EDA_X_SupWorse=mu2+sigma2.*randn(N,D);
    EDA_X=mu3+sigma3.*randn(N,D);
    V=EDA_X+rand(N,D).*(EDA_X_SupBetter+EDA_X_SupWorse-2*EDA_X);
    CR=exp(-(4*FEs/MaxFEs)^2)*rand(N,D);
    Logic_CR=rand(N,D)<CR;
    SumLogical=sum(Logic_CR,2);
    for i=1:N
        if ~SumLogical(i)
            Logic_CR(i,randi(D))=true;
        end
    end
    U=X;
    U(Logic_CR)=V(Logic_CR); 

    % Boundary constraints
    flagub=U>ub;
    flaglb=U<lb;
    flag=(flagub+flaglb);
    U=(U.*(~flag))+(lb+(ub-lb)*rand(N,D)).*flag;

    %% Metropolis criterion and individual regeneration selection strategy
    ufitness=Func(U',FuncId);
    for i=1:N
        if ufitness(i)<f(i)
            new_state(i)=1;
            life(i)=0;
            X(i,:)=U(i,:);
            f(i)=ufitness(i);
            FEs=FEs+1;
            if gbestfitness>f(i)
                gbestfitness=f(i);
                gbestX=X(i,:);
            end
            gbesthistory(FEs)=gbestfitness;
        else
            new_state(i)=2;
            FEs=FEs+1;
            gbesthistory(FEs)=gbestfitness;
            if rand<=exp(-((ufitness(i)-f(i))/f(i))/T)
                X(i,:)=U(i,:);
                f(i)=ufitness(i);
            else
                life(i)=life(i)+1;
                if life(i)>=life_end(i)
                    life_end(i)=life_end(i)+N;
                    if rand<rand
                        X(i,:)=lb+(ub-lb)*rand(1,D);
                    else
                        Rp=randperm(D,ceil(D*rand));
                        X(i,Rp)=lb+(ub-lb)*rand(1,length(Rp));
                    end
                    f(i)=Func(X(i,:)',FuncId);
                    FEs=FEs+1;
                    if gbestfitness>f(i)
                        gbestfitness=f(i);
                        gbestX=X(i,:);
                    end
                    gbesthistory(FEs)=gbestfitness;
                end
            end
        end
        if FEs>=MaxFEs
            break;
        end
    end
    T=T*0.99;
    if FEs>=MaxFEs
        break;
    end

end % end while
end % end SFG-DE