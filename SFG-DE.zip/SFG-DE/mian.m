% SFG-DE: An explainable and evolvable differential evolution for learning to generate operator structures
% Structural Fuzzy Generative Differential Evolution (SFG-DE)
rng('shuffle');
D=10;
lb=-100;
ub=100;
Func=@cec17_func;
MaxFEs=10000*D;
N=10+15*floor((log(D+1)));
for FuncId=1:30
    [gbestX,gbestfitness,gbesthistory]=SFG_DE(N,D,ub,lb,MaxFEs,Func,FuncId);
    fprintf("SFG-DE function F%d, optimial error = %e\n",FuncId,gbestfitness);
end